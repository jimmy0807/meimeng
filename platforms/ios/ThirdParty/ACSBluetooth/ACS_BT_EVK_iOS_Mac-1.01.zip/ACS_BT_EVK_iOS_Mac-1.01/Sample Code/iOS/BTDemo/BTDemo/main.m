//
//  main.m
//  BTDemo
//
//  Created by godfrey on 20/5/14.
//  Copyright (c) 2014 Advanced Card Systems Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ABDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ABDAppDelegate class]));
    }
}
