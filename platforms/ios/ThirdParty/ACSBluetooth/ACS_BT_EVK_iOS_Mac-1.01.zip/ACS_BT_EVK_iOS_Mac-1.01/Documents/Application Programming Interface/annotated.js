var annotated =
[
    [ "ABTAcr1255uj1Reader", "interface_a_b_t_acr1255uj1_reader.html", "interface_a_b_t_acr1255uj1_reader" ],
    [ "ABTAcr3901us1Reader", "interface_a_b_t_acr3901us1_reader.html", "interface_a_b_t_acr3901us1_reader" ],
    [ "ABTBluetoothReader", "interface_a_b_t_bluetooth_reader.html", "interface_a_b_t_bluetooth_reader" ],
    [ "<ABTBluetoothReaderDelegate>", "protocol_a_b_t_bluetooth_reader_delegate-p.html", "protocol_a_b_t_bluetooth_reader_delegate-p" ],
    [ "ABTBluetoothReaderManager", "interface_a_b_t_bluetooth_reader_manager.html", "interface_a_b_t_bluetooth_reader_manager" ],
    [ "<ABTBluetoothReaderManagerDelegate>", "protocol_a_b_t_bluetooth_reader_manager_delegate-p.html", "protocol_a_b_t_bluetooth_reader_manager_delegate-p" ]
];