var interface_a_b_t_bluetooth_reader_manager =
[
    [ "detectReaderWithPeripheral:", "interface_a_b_t_bluetooth_reader_manager.html#a274499e2cfc9242c0b9987e496b88b68", null ],
    [ "delegate", "interface_a_b_t_bluetooth_reader_manager.html#ae4096c07a34b944b1690701ceca8cb19", null ]
];