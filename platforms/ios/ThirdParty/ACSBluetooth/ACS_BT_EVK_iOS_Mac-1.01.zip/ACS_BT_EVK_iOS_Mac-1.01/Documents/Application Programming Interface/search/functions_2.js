var searchData=
[
  ['detach',['detach',['../interface_a_b_t_bluetooth_reader.html#ae527fdd56830ef7795fc4448f55e3c46',1,'ABTBluetoothReader']]],
  ['detectreaderwithperipheral_3a',['detectReaderWithPeripheral:',['../interface_a_b_t_bluetooth_reader_manager.html#a274499e2cfc9242c0b9987e496b88b68',1,'ABTBluetoothReaderManager']]]
];
