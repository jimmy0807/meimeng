var interface_a_b_t_acr1255uj1_reader =
[
    [ "getBatteryLevel", "interface_a_b_t_acr1255uj1_reader.html#a0326aed29006f73491a0f8be26d21468", null ]
];