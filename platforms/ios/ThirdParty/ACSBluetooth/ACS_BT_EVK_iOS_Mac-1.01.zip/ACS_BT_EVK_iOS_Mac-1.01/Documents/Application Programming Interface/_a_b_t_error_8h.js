var _a_b_t_error_8h =
[
    [ "ABTErrorInvalidChecksum", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a348aea5af22f2a77b7e31219c6da3ea5", null ],
    [ "ABTErrorInvalidDataLength", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a14133e98ced4a03c615b23a5f2eca0a5", null ],
    [ "ABTErrorInvalidCommand", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04ad5d89f1ccd23afa9839701ab35877796", null ],
    [ "ABTErrorUnknownCommandId", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a335a7312ca64ac5d475bbdfdf82575c8", null ],
    [ "ABTErrorCardOperation", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04aa0861da008fe3c13ed76ba7c4ee733cc", null ],
    [ "ABTErrorAuthenticationRequired", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04ac007dd2bd123c66104ec62a1b36f528c", null ],
    [ "ABTErrorLowBattery", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04ae7cddc8df3abb29868c566dab49e32ed", null ],
    [ "ABTErrorAuthenticationFailed", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04aaee7cf04d1dff03b57827f4d9b4c05f2", null ],
    [ "ABTErrorCharacteristicNotFound", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a7867a127e31c6b7ef098c2da5fb38a63", null ],
    [ "ABTErrorServiceNotFound", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04ad36cbed3b3659cd3e2d46c3041d27f5c", null ],
    [ "ABTErrorReaderNotFound", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04abc90388af254a9aa18feb040a2753f60", null ],
    [ "ABTErrorCommandFailed", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a98cba5bc5d370937d4a7921b1b62aa1b", null ],
    [ "ABTErrorTimeout", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a4f91121faf3e6ef2f968329fd4cc81a8", null ],
    [ "ABTErrorUndefined", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a9cd5b5270fcb3d052fa49b3fbb5a215c", null ],
    [ "ABTErrorInvalidData", "_a_b_t_error_8h.html#abc6126af1d45847bc59afa0aa3216b04a07abec59b5e3aa253b8908c9b6b962ac", null ],
    [ "ABTErrorDomain", "_a_b_t_error_8h.html#acd351a0af71c63157fcc972d8bc94a23", null ]
];