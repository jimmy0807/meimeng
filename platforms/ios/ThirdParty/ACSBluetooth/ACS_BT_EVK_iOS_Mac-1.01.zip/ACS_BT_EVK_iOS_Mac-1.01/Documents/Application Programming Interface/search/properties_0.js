var searchData=
[
  ['delegate',['delegate',['../interface_a_b_t_bluetooth_reader.html#a1221ef8c1e14fcd88e242def40c55dcd',1,'ABTBluetoothReader::delegate()'],['../interface_a_b_t_bluetooth_reader_manager.html#ae4096c07a34b944b1690701ceca8cb19',1,'ABTBluetoothReaderManager::delegate()']]]
];
