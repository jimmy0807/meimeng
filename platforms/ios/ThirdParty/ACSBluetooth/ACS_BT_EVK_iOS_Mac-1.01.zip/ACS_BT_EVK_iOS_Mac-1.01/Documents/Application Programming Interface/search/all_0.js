var searchData=
[
  ['_5fattached',['_attached',['../interface_a_b_t_bluetooth_reader.html#aec875edbcdab59bf9db623519bf06142',1,'ABTBluetoothReader']]],
  ['_5fperipheral',['_peripheral',['../interface_a_b_t_bluetooth_reader.html#a6eec2f2b1e4810233acbbb7e6102fe6d',1,'ABTBluetoothReader']]]
];
