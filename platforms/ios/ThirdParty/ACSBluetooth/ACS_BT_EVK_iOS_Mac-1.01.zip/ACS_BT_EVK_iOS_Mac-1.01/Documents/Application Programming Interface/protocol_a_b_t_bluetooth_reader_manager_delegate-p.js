var protocol_a_b_t_bluetooth_reader_manager_delegate_p =
[
    [ "bluetoothReaderManager:didDetectReader:peripheral:error:", "protocol_a_b_t_bluetooth_reader_manager_delegate-p.html#a984f294bde6383bda3e008ffdff7e093", null ]
];