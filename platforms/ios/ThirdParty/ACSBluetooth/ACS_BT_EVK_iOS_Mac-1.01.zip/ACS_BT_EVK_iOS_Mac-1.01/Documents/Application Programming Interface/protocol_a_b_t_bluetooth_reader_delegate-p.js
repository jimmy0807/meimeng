var protocol_a_b_t_bluetooth_reader_delegate_p =
[
    [ "bluetoothReader:didAttachPeripheral:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#ae997a68e52d7fe3a4ccadbd924c1a732", null ],
    [ "bluetoothReader:didAuthenticateWithError:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a7ced6c91f3f9443113e9c5c8d96289a6", null ],
    [ "bluetoothReader:didChangeBatteryLevel:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a9d2822a52a1d2a937624c77b42022bb8", null ],
    [ "bluetoothReader:didChangeBatteryStatus:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a610f162aef022b71c0c31fa82ae03254", null ],
    [ "bluetoothReader:didChangeCardStatus:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#ac2a01961e70c9100eea2e87fab5b3841", null ],
    [ "bluetoothReader:didPowerOffCardWithError:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a18fbe85a8fdfd0a71e3ed2a7cd77a92a", null ],
    [ "bluetoothReader:didReturnAtr:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a247b6ff8882278fe9da6ad86e4120e3d", null ],
    [ "bluetoothReader:didReturnCardStatus:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a6ff6e74428d1422d8640841fb17fa618", null ],
    [ "bluetoothReader:didReturnDeviceInfo:type:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a36e3b0e2e1a49936fc0a0fed02364941", null ],
    [ "bluetoothReader:didReturnEscapeResponse:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a7ca805709a1a60e04ec8eb215e503ef8", null ],
    [ "bluetoothReader:didReturnResponseApdu:error:", "protocol_a_b_t_bluetooth_reader_delegate-p.html#a4b336811bf75ae71ece346266079afac", null ]
];