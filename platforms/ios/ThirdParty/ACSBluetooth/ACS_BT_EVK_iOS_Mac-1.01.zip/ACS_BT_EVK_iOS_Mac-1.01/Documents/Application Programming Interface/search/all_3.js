var searchData=
[
  ['delegate',['delegate',['../interface_a_b_t_bluetooth_reader.html#a1221ef8c1e14fcd88e242def40c55dcd',1,'ABTBluetoothReader::delegate()'],['../interface_a_b_t_bluetooth_reader_manager.html#ae4096c07a34b944b1690701ceca8cb19',1,'ABTBluetoothReaderManager::delegate()']]],
  ['detach',['detach',['../interface_a_b_t_bluetooth_reader.html#ae527fdd56830ef7795fc4448f55e3c46',1,'ABTBluetoothReader']]],
  ['detectreaderwithperipheral_3a',['detectReaderWithPeripheral:',['../interface_a_b_t_bluetooth_reader_manager.html#a274499e2cfc9242c0b9987e496b88b68',1,'ABTBluetoothReaderManager']]]
];
