var hierarchy =
[
    [ "NSObject", null, [
      [ "ABTBluetoothReader", "interface_a_b_t_bluetooth_reader.html", [
        [ "ABTAcr1255uj1Reader", "interface_a_b_t_acr1255uj1_reader.html", null ],
        [ "ABTAcr3901us1Reader", "interface_a_b_t_acr3901us1_reader.html", null ]
      ] ],
      [ "ABTBluetoothReaderManager", "interface_a_b_t_bluetooth_reader_manager.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<ABTBluetoothReaderDelegate>", "protocol_a_b_t_bluetooth_reader_delegate-p.html", null ],
      [ "<ABTBluetoothReaderManagerDelegate>", "protocol_a_b_t_bluetooth_reader_manager_delegate-p.html", null ]
    ] ]
];