var interface_a_b_t_bluetooth_reader =
[
    [ "attachPeripheral:", "interface_a_b_t_bluetooth_reader.html#af276c7681598720fef558c92d1eebb23", null ],
    [ "authenticateWithMasterKey:", "interface_a_b_t_bluetooth_reader.html#a51f95182d491934d946f8ce803849cca", null ],
    [ "authenticateWithMasterKey:length:", "interface_a_b_t_bluetooth_reader.html#a8983398af6c6b9383fc16c29b5881f31", null ],
    [ "detach", "interface_a_b_t_bluetooth_reader.html#ae527fdd56830ef7795fc4448f55e3c46", null ],
    [ "getCardStatus", "interface_a_b_t_bluetooth_reader.html#aff111e5164b3681c30720b5729353ab6", null ],
    [ "getDeviceInfoWithType:", "interface_a_b_t_bluetooth_reader.html#aba727cc01975b9b45a9fd6e298889f9c", null ],
    [ "powerOffCard", "interface_a_b_t_bluetooth_reader.html#a9a6877979b8b23a3662c0bf80b5aa87d", null ],
    [ "powerOnCard", "interface_a_b_t_bluetooth_reader.html#ada320b8ccb71fa55c0a36a4e272c4209", null ],
    [ "transmitApdu:", "interface_a_b_t_bluetooth_reader.html#a93385cc284f9839626018004ce54a9d3", null ],
    [ "transmitApdu:length:", "interface_a_b_t_bluetooth_reader.html#a23dbf355ec630ee2dfe840889a162f99", null ],
    [ "transmitEscapeCommand:", "interface_a_b_t_bluetooth_reader.html#abccbcb0d14738a346827fd49364ea64e", null ],
    [ "transmitEscapeCommand:length:", "interface_a_b_t_bluetooth_reader.html#afd52c74d25f0dc01f4b268d824ca8202", null ],
    [ "_attached", "interface_a_b_t_bluetooth_reader.html#aec875edbcdab59bf9db623519bf06142", null ],
    [ "_peripheral", "interface_a_b_t_bluetooth_reader.html#a6eec2f2b1e4810233acbbb7e6102fe6d", null ],
    [ "delegate", "interface_a_b_t_bluetooth_reader.html#a1221ef8c1e14fcd88e242def40c55dcd", null ]
];