var interface_a_b_t_acr3901us1_reader =
[
    [ "getBatteryStatus", "interface_a_b_t_acr3901us1_reader.html#aab99d6c97a976674b73ab9a64b9899bf", null ]
];