var searchData=
[
  ['getbatterylevel',['getBatteryLevel',['../interface_a_b_t_acr1255uj1_reader.html#a0326aed29006f73491a0f8be26d21468',1,'ABTAcr1255uj1Reader']]],
  ['getbatterystatus',['getBatteryStatus',['../interface_a_b_t_acr3901us1_reader.html#aab99d6c97a976674b73ab9a64b9899bf',1,'ABTAcr3901us1Reader']]],
  ['getcardstatus',['getCardStatus',['../interface_a_b_t_bluetooth_reader.html#aff111e5164b3681c30720b5729353ab6',1,'ABTBluetoothReader']]],
  ['getdeviceinfowithtype_3a',['getDeviceInfoWithType:',['../interface_a_b_t_bluetooth_reader.html#aba727cc01975b9b45a9fd6e298889f9c',1,'ABTBluetoothReader']]]
];
