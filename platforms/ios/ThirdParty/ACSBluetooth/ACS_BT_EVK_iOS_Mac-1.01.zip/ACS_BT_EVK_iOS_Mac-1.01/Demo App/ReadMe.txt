ACS Bluetooth iOS App
Advanced Card Systems Ltd.

Introduction
------------
The ACS Bluetooth app is designed for use with ACR3901U-S1, ACR3901T-W1, and ACR1255U-J1 Bluetooth Card Readers.

System Requirements


- iOS 8.0 or above.

- iPhone 4S or above.


- Mac OS X 10.7 or above.

- Mac with Bluetooth 4.0.



Development Environment


- Xcode 9.3 or above.



Supported Readers


- ACR3901U-S1 (v1.04 or above)

- ACR1255U-J1 (v1.12 or above)





Installation

------------


1. To use the class library to your project, copy "BTDemo\ACSBluetooth"
 folder to your project folder and drag it to your project in the Xcode.

2. Select Build Settings tab in the Targets.

3. Add "$(PROJECT_DIR)" to the Header Search Paths.

4. Add "-ObjC" to Other Linker Flags.


5. Select General tab in the Targets and click "+" in Linked Frameworks and
 Libraries.


6. When a dialog appears, click on "Add Other..." button to add
   "libACSBluetooth.a" to your project.





Support
-------
In case there any issue encountered, please contact ACS:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286
